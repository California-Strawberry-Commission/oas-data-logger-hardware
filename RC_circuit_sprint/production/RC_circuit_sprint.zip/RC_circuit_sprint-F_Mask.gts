G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.5*
G04 #@! TF.CreationDate,2026-04-27T15:09:50-07:00*
G04 #@! TF.ProjectId,RC_circuit_sprint,52435f63-6972-4637-9569-745f73707269,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.5) date 2026-04-27 15:09:50*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.265778X-0.647222X0.332222X-0.647222X-0.332222X0.647222X-0.332222X0.647222X0.332222X0*%
%ADD11C,4.800000*%
%ADD12RoundRect,0.266521X0.671479X-0.346479X0.671479X0.346479X-0.671479X0.346479X-0.671479X-0.346479X0*%
%ADD13C,5.000000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,R2*
X123500000Y-70480000D03*
X123500000Y-73400000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,Vin1*
X116500000Y-67500000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,C1*
X126000000Y-73480000D03*
X126000000Y-70520000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,GND1*
X116500000Y-75500000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,H1*
X133500000Y-76500000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,Vout1*
X132500000Y-67500000D03*
G04 #@! TD*
M02*
